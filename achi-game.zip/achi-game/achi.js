$(document).ready(function() {
//variable Declaration for 9 circles 
var cir1 = $('#circle1'),
    cir2 = $('#circle2'),
    cir3 = $('#circle3'),
    cir4 = $('#circle4'),
    cir5 = $('#circle5'),
    cir6 = $('#circle6'),
    cir7 = $('#circle7'),
    cir8 = $('#circle8'),
    cir9 = $('#circle9'),
    playValid = false,
    win = false;

	function validatePlay(circleplayed) {
		if ($(circleplayed).hasClass('emptycircle')) {
			playValid = true;
		} else {
			playValid = false;
			return false;
		}
	}

	function clearAchi() {
		$('.achi').removeClass('played').removeClass('computer').removeClass('user').addClass('emptycircle');
	}

	function winAchi(player) {
		win = true;
		if (player == "user")
			alert("Congratulations, you beat the computer!");
		else
			alert("You lost the match!");	
		clearAchi();
	}

	function checkAchiWin() {
		var cir123_user     = (cir1.hasClass('user') && cir2.hasClass('user') && cir3.hasClass('user')),
			cir123_computer = (cir1.hasClass('computer') && cir2.hasClass('computer') && cir3.hasClass('computer')),
			cir456_user     = (cir4.hasClass('user') && cir5.hasClass('user') && cir6.hasClass('user')),
			cir456_computer = (cir4.hasClass('computer') && cir5.hasClass('computer') && cir6.hasClass('computer')),
			cir789_user     = (cir7.hasClass('user') && cir8.hasClass('user') && cir9.hasClass('user')),
			cir789_computer = (cir7.hasClass('computer') && cir8.hasClass('computer') && cir9.hasClass('computer')),
			cir147_user     = (cir1.hasClass('user') && cir4.hasClass('user') && cir7.hasClass('user'));
			cir147_computer = cir1.hasClass('computer') && cir4.hasClass('computer') && cir7.hasClass('computer'),
			cir528_user     = cir5.hasClass('user') && cir2.hasClass('user') && cir8.hasClass('user'),
			cir528_computer = cir5.hasClass('computer') && cir2.hasClass('computer') && cir8.hasClass('computer'),
			cir693_user     = cir6.hasClass('user') && cir9.hasClass('user') && cir3.hasClass('user'),
			cir693_computer = cir6.hasClass('computer') && cir9.hasClass('computer') && cir3.hasClass('computer'),
			cir159_user     = cir1.hasClass('user') && cir5.hasClass('user') && cir9.hasClass('user'),
			cir159_computer = cir1.hasClass('computer') && cir5.hasClass('computer') && cir9.hasClass('computer'),
			cir573_user     = cir5.hasClass('user') && cir7.hasClass('user') && cir3.hasClass('user'),
			cir573_computer = cir5.hasClass('computer') && cir7.hasClass('computer') && cir3.hasClass('computer');
		switch (true) {
		  case (cir123_user || cir456_user || cir789_user || cir528_user || cir693_user || cir159_user || cir573_user):
			winAchi("user");
			break;
		  case (cir123_computer || cir456_computer || cir789_computer || cir147_computer || cir528_computer || cir693_computer || cir573_computer):
			winAchi("computer");
			break;
		}
	}

	function checkDrawMatch() {
		if (!($('.achi').hasClass('emptycircle'))) {
			alert("Match Draw! Try playing again!");
			clearAchi();
		}
	}

	function computerplay() {
		win123_cir3 = (cir1.hasClass('user') && cir2.hasClass('user') || cir1.hasClass('computer') && cir2.hasClass('computer')) && !(cir3.hasClass('played'));
		win123_cir2 = (cir1.hasClass('user') && cir3.hasClass('user') || cir1.hasClass('computer') && cir3.hasClass('computer')) && !(cir2.hasClass('played'));
		win123_cir1 = (cir3.hasClass('user') && cir2.hasClass('user') || cir3.hasClass('computer') && cir2.hasClass('computer')) && !(cir1.hasClass('played'));

		win456_cir6 = (cir4.hasClass('user') && cir5.hasClass('user') || cir4.hasClass('computer') && cir5.hasClass('computer')) && !(cir6.hasClass('played'));
		win456_cir5 = (cir4.hasClass('user') && cir6.hasClass('user') || cir4.hasClass('computer') && cir6.hasClass('computer')) && !(cir5.hasClass('played'));
		win456_cir4 = (cir5.hasClass('user') && cir6.hasClass('user') || cir5.hasClass('computer') && cir6.hasClass('computer')) && !(cir4.hasClass('played'));

		win789_cir9 = (cir7.hasClass('user') && cir8.hasClass('user') || cir7.hasClass('computer') && cir8.hasClass('computer')) && !(cir9.hasClass('played'));
		win789_cir8 = (cir7.hasClass('user') && cir9.hasClass('user') || cir7.hasClass('computer') && cir9.hasClass('computer')) && !(cir8.hasClass('played'));
		win789_cir7 = (cir8.hasClass('user') && cir9.hasClass('user') || cir8.hasClass('computer') && cir9.hasClass('computer')) && !(cir7.hasClass('played'));

		win147_cir7 = (cir1.hasClass('user') && cir4.hasClass('user') || cir1.hasClass('computer') && cir4.hasClass('computer')) && !(cir7.hasClass('played'));
		win147_cir4 = (cir1.hasClass('user') && cir7.hasClass('user') || cir1.hasClass('computer') && cir7.hasClass('computer')) && !(cir4.hasClass('played'));
		win147_cir1 = (cir4.hasClass('user') && cir7.hasClass('user') || cir4.hasClass('computer') && cir7.hasClass('computer')) && !(cir1.hasClass('played'));

		win528_cir8 = (cir5.hasClass('user') && cir2.hasClass('user') || cir5.hasClass('computer') && cir2.hasClass('computer')) && !(cir8.hasClass('played'));
		win528_cir2 = (cir5.hasClass('user') && cir8.hasClass('user') || cir5.hasClass('computer') && cir8.hasClass('computer')) && !(cir2.hasClass('played'));
		win528_cir5 = (cir2.hasClass('user') && cir8.hasClass('user') || cir2.hasClass('computer') && cir8.hasClass('computer')) && !(cir5.hasClass('played'));

		win693_cir3 = (cir6.hasClass('user') && cir9.hasClass('user') || cir6.hasClass('computer') && cir9.hasClass('computer')) && !(cir3.hasClass('played'));
		win693_cir9 = (cir6.hasClass('user') && cir3.hasClass('user') || cir6.hasClass('computer') && cir3.hasClass('computer')) && !(cir9.hasClass('played'));
		win693_cir6 = (cir9.hasClass('user') && cir3.hasClass('user') || cir9.hasClass('computer') && cir3.hasClass('computer')) && !(cir6.hasClass('played'));

		win159_cir9 = (cir1.hasClass('user') && cir5.hasClass('user') || cir1.hasClass('computer') && cir5.hasClass('computer')) && !(cir9.hasClass('played'));
		win159_cir5 = (cir1.hasClass('user') && cir9.hasClass('user') || cir1.hasClass('computer') && cir9.hasClass('computer')) && !(cir5.hasClass('played'));
		win159_cir1 = (cir5.hasClass('user') && cir9.hasClass('user') || cir5.hasClass('computer') && cir9.hasClass('computer')) && !(cir1.hasClass('played'));

		win573_cir3 = (cir5.hasClass('user') && cir7.hasClass('user') || cir5.hasClass('computer') && cir7.hasClass('computer')) && !(cir3.hasClass('played'));
		win573_cir5 = (cir5.hasClass('user') && cir3.hasClass('user') || cir5.hasClass('computer') && cir3.hasClass('computer')) && !(cir5.hasClass('played'));
		win573_cir7 = (cir7.hasClass('user') && cir3.hasClass('user') || cir7.hasClass('computer') && cir3.hasClass('computer')) && !(cir7.hasClass('played'));


		// Win 1 2 3
		if (win123_cir3)
			computerplaying(cir3);
		else if (win123_cir2)
			computerplaying(cir2);
		else if (win123_cir1)
			computerplaying(cir1);
		// Win 4 5 6
		else if (win456_cir6)
			computerplaying(cir6);
		else if (win456_cir5)
			computerplaying(cir5);
		else if (win456_cir4)
			computerplaying(cir4);
		// Win 7 8 9 
		else if (win789_cir9)
			computerplaying(cir9);
		else if (win789_cir8)
			computerplaying(cir8);
		else if (win789_cir7)
			computerplaying(cir7);
		// Win 1 4 7
		else if (win147_cir7)
			computerplaying(cir7);
		else if (win147_cir4)
			computerplaying(cir4);
		else if (win147_cir1)
			computerplaying(cir1);

		// Win 5 2 8
		else if (win528_cir8)
			computerplaying(cir8);
		else if (win528_cir2)
			computerplaying(cir2)
		else if (win528_cir5)
			computerplaying(cir5);
		// Win 6 9 3
		else if (win693_cir3)
			computerplaying(cir3);
		else if (win693_cir9)
			computerplaying(cir9);
		else if (win693_cir6)
			computerplaying(cir6);
		// Win 1 5 9
		else if (win159_cir9)
			computerplaying(cir9);
		else if (win159_cir5)
			computerplaying(cir5);
		else if (win159_cir1)
			computerplaying(cir1);

		// Win 5 7 3
		else if (win573_cir3)
			computerplaying(cir3);
		else if (win573_cir7)
			computerplaying(cir7);
		else if (win573_cir5)
			computerplaying(cir5);
		else
			Orandomplay();
		
		checkDrawMatch();
		checkAchiWin();
	}


    // Function for when O plays tactically
	function computerplaying(circle) {
		validatePlay(circle);
        if (playValid) 
			circle.removeClass('emptycircle').addClass('played').addClass('computer');
		else 
			Orandomplay();
	}

	// Function for when O plays randomly
	function Orandomplay() {
		for (var i = 0; i < 10; i++) {
		// Loop to find a valid play		
			var randomNumber = Math.floor((Math.random() * 9) + 1);
			var randomcircle = $('#circle'+randomNumber);
			validatePlay(randomcircle);

			if (playValid) {
				randomcircle.removeClass('emptycircle');
				randomcircle.addClass('played');
				randomcircle.addClass('computer');
				break;
			} 
		}
	}

	$('.achi').on('click', function Xplay() {
		//condition to remove the 
		validatePlay(this);
		if (playValid) {
			$(this).removeClass('emptycircle');
			$(this).addClass('played');
			$(this).addClass('user');
			checkDrawMatch();
			checkAchiWin();
			computerplay();
		} else {
			alert("That circle has already been played. Please choose another circle");
		}	
	});

	$('.button').on('click', function() {
		clearAchi();
	});
}); 